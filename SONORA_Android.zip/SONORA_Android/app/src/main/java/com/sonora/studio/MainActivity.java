package com.sonora.studio;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.text.InputType;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int MAX_SECONDS = 300;
    private final ArrayList<Uri> imageUris = new ArrayList<>();
    private Uri audioUri;
    private LinearLayout root, imageList;
    private EditText titleInput, musicPrompt, lyricInput, visualPrompt;
    private TextView audioLabel, imagesLabel, lengthLabel, statusLabel;
    private SeekBar lengthSeek;
    private Spinner genreSpinner, styleSpinner;
    private int chosenLength = MAX_SECONDS;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildUi();
    }

    private int dp(float x) { return (int)(x * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawableBuilder unused;

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(11,11,18));
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(20),dp(18),dp(32));
        scroll.addView(root); setContentView(scroll);

        TextView brand = text("SONORA", 30, true, 0xFFCD8BFF);
        root.addView(brand);
        root.addView(text("AI MUSIC  ×  MUSIC VIDEO STUDIO", 12, true, 0xFFB4B1C8));
        root.addView(text("Készíts zenét és hozzá klipet egy alkalmazásban.", 15, false, 0xFFECEAF6));
        section("01  ·  ZENE LÉTREHOZÁSA");
        titleInput = edit("Dal címe", false); root.addView(titleInput);
        musicPrompt = edit("Írd le a zenét: pl. magyar trap, agresszív reggaeton refrén, 100 BPM…", true); root.addView(musicPrompt);
        genreSpinner = spinner(new String[]{"Trap / Rap", "Reggaeton", "Afrobeat", "Pop", "Rock", "Cinematic", "Lo-fi", "Elektronikus"}); root.addView(genreSpinner);
        Button generateMusic = button("ZENE GENERÁLÁSÁNAK ELŐKÉSZÍTÉSE"); root.addView(generateMusic);
        generateMusic.setOnClickListener(v -> showProviderNotice("A zenegeneráláshoz AI-szolgáltató szükséges. A Suno nem tartalmaz szabadon használható, korlátlan API-t. A nyílt MusicGen külön telepített szerveren futtatható, de a modellek licencfeltételeit ellenőrizni kell."));
        audioLabel = text("Nincs kiválasztott hangfájl", 13, false, 0xFFB5B1C7); root.addView(audioLabel);
        Button chooseAudio = button("SAJÁT ZENE BETÖLTÉSE"); root.addView(chooseAudio);
        chooseAudio.setOnClickListener(v -> pickAudio());

        section("02  ·  ANIMÁLT VIDEÓ");
        visualPrompt = edit("Videóötlet: füstből előtűnő felirat, városi éjszaka, filmszerű fények…", true); root.addView(visualPrompt);
        styleSpinner = spinner(new String[]{"Neon Trap", "Reggaeton Club", "Cinematic", "Smoke & Fire", "Anime Motion", "Dreamwave", "Minimal Lyric Video"}); root.addView(styleSpinner);
        imagesLabel = text("0 / 30 kép kiválasztva", 14, true, 0xFFDDD8EF); root.addView(imagesLabel);
        Button addImages = button("TÖBB KÉP HOZZÁADÁSA"); root.addView(addImages);
        addImages.setOnClickListener(v -> pickImages());
        imageList = new LinearLayout(this); imageList.setOrientation(LinearLayout.VERTICAL); root.addView(imageList);
        section("03  ·  KLIP HOSSZA");
        lengthLabel = text("Maximális hossz: 5:00 perc", 16, true, 0xFFCD8BFF); root.addView(lengthLabel);
        lengthSeek = new SeekBar(this); lengthSeek.setMax(MAX_SECONDS); lengthSeek.setProgress(MAX_SECONDS); root.addView(lengthSeek);
        lengthSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { chosenLength = Math.max(10, Math.min(MAX_SECONDS, p)); lengthLabel.setText(String.format(Locale.getDefault(), "Maximális hossz: %d:%02d (legfeljebb 5:00)", chosenLength/60, chosenLength%60)); }
            public void onStartTrackingTouch(SeekBar s) {} public void onStopTrackingTouch(SeekBar s) {}
        });
        section("04  ·  KIMENET");
        statusLabel = text("A generálómotorok nincsenek még csatlakoztatva.", 13, false, 0xFFFFD38C); root.addView(statusLabel);
        Button makeVideo = button("KLIP PROJEKT ELŐKÉSZÍTÉSE"); root.addView(makeVideo);
        makeVideo.setOnClickListener(v -> buildProjectSummary());
        TextView foot = text("Az alkalmazás felülete ingyenes. Valódi AI-zenéhez és AI-mozgáshoz modell vagy szolgáltatás kell; a korlátlan felhőgenerálás nem garantálható ingyen.", 12, false, 0xFF9490A7); root.addView(foot);
    }

    private TextView text(String s, int size, boolean bold, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setPadding(0,dp(7),0,dp(7));
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private void section(String s) { TextView t=text(s,14,true,0xFFCD8BFF); t.setPadding(0,dp(24),0,dp(8)); root.addView(t); }
    private EditText edit(String hint, boolean multiline) {
        EditText e = new EditText(this); e.setTextColor(Color.WHITE); e.setHintTextColor(0xFF8E8AA3); e.setHint(hint); e.setTextSize(14);
        e.setPadding(dp(13),dp(12),dp(13),dp(12)); e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF76618C));
        if (multiline) { e.setMinLines(3); e.setGravity(Gravity.TOP); e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE); }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(8); e.setLayoutParams(lp); return e;
    }
    private Spinner spinner(String[] entries) {
        Spinner s=new Spinner(this); ArrayAdapter<String> a=new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, entries); s.setAdapter(a);
        s.setPadding(dp(6),dp(7),dp(6),dp(7)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48)); lp.bottomMargin=dp(7); s.setLayoutParams(lp); return s;
    }
    private Button button(String label) {
        Button b=new Button(this); b.setText(label); b.setTextSize(12); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF783BC1));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52)); lp.bottomMargin=dp(8); b.setLayoutParams(lp); return b;
    }
    private void pickAudio() { Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("audio/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,11); }
    private void pickImages() { Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,12); }
    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req,result,data); if (result!=RESULT_OK || data==null) return;
        if(req==11 && data.getData()!=null) { audioUri=data.getData(); audioLabel.setText("Hang kiválasztva: "+audioUri.getLastPathSegment()); }
        if(req==12) {
            if(data.getClipData()!=null) { for(int k=0;k<data.getClipData().getItemCount() && imageUris.size()<30;k++) imageUris.add(data.getClipData().getItemAt(k).getUri()); }
            else if(data.getData()!=null && imageUris.size()<30) imageUris.add(data.getData());
            renderImages();
        }
    }
    private void renderImages() {
        imageList.removeAllViews(); imagesLabel.setText(imageUris.size()+" / 30 kép kiválasztva");
        for(int n=0;n<imageUris.size();n++) {
            final int idx=n; LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(8),dp(4),dp(8),dp(4));
            TextView name=text((n+1)+". "+imageUris.get(n).getLastPathSegment(),12,false,Color.WHITE); name.setMaxLines(1); row.addView(name,new LinearLayout.LayoutParams(0,-2,1));
            Button del=new Button(this); del.setText("×"); del.setOnClickListener(v->{imageUris.remove(idx);renderImages();}); row.addView(del); imageList.addView(row);
        }
    }
    private void showProviderNotice(String message) { new android.app.AlertDialog.Builder(this).setTitle("AI-motor csatlakoztatása").setMessage(message).setPositiveButton("Értem",null).show(); }
    private void buildProjectSummary() {
        String summary="SONORA klipprojekt\nDal: "+(titleInput.getText().toString().trim().isEmpty()?"Névtelen dal":titleInput.getText())+
            "\nMűfaj: "+genreSpinner.getSelectedItem()+"\nVideóstílus: "+styleSpinner.getSelectedItem()+"\nKépek: "+imageUris.size()+
            "\nMaximális hossz: "+chosenLength+" mp\n\nAI-generálás és MP4-renderelés nincs még bekötve. Ez a változat a projekt beállításait állítja össze.";
        statusLabel.setText(summary); new android.app.AlertDialog.Builder(this).setTitle("Projekt előkészítve").setMessage(summary).setPositiveButton("Rendben",null).show();
    }
    // Placeholder to keep source dependency-free. Visual design uses Android widgets only.
    private static class GradientDrawableBuilder {}
}
